let counterDark = 1
let submenuCounter = document.getElementsByClassName('menu_desktop')[0].children[0].children
let menuMobileColor = document.getElementsByClassName('menu_mobile')[0]
let moon_sun_mob = document.getElementsByClassName('backgroundButtonMob')[3].children
let price_container_color = document.getElementsByClassName('price_container')[0]
let _priceBoxes = document.getElementsByClassName('boxes')[0].children
let _table_container_color = document.getElementsByClassName('table_container')[0]
let _table_watch_color = document.getElementsByClassName('_table_watch_protfolio')[0].children
let _table_filters_color = document.getElementsByClassName('_table_filters')[0].children
_list_color = _table_filters_color[2].children[0]
let subscribe_container_color = document.getElementsByClassName('subscribe_container')[0]
let _bodyColor = document.getElementsByTagName('body')[0]
let _subscribe_image_color = document.getElementsByClassName('subscribeImage')[0].children
let slider_box_color = document.getElementById('bus').children
function _darkMode(){
    let head_top_span = document.getElementsByClassName('head_top')[0].children
    let head_top_span_sun = document.getElementsByClassName('darkmode')[0].children
    let _logoDes = document.getElementsByClassName('logo')[0]
    let _logoMob = document.getElementsByClassName('logo')[1]
    let _logoFooter = document.getElementsByClassName('logo')[2]



    if(counterDark%2){
        // body color
        _bodyColor.style.backgroundColor='#17171A'
        // headtop main logo
        document.getElementsByTagName('main')[0].style.backgroundColor='#17171A'
        head_top_span[1].style.color='white'
        head_top_span_sun[0].style.display='none'
        head_top_span_sun[1].style.display='block'
        // logo
        _logoDes.style.fill='white'
        _logoMob.style.fill='white'
        _logoFooter.style.fill='white'
        // input form
        document.getElementsByTagName('input')[0].style.backgroundColor='#232531'
        // menuMobileColor
        menuMobileColor.style.backgroundColor='#17171A'
        
        // moon sun mob
        moon_sun_mob[0].style.display='none'
        moon_sun_mob[1].style.display='block'

        // price container
        price_container_color.style.backgroundColor='#232531'

        // _table_container_color
        _table_container_color.style.backgroundColor='#17171A'

        // price Boxes
        for(i=0;i<_priceBoxes.length;i++){
            _priceBoxes[i].style.backgroundColor='#333546'
        }
       for(i=0;i<slider_box_color.length;i++){
        slider_box_color[i].style.backgroundColor='#333546'
       }

        // table_watch color
        for(i=0;i<_table_watch_color.length;i++){
            _table_watch_color[i].style.backgroundColor='#333546'
        }
        // _table_filters_color
        for(i=0;i<_table_filters_color.length;i++){
            _table_filters_color[i].style.backgroundColor='#333546'
        }
        _list_color.style.backgroundColor='#17171A'
        document.getElementsByClassName('list_color')[0].style.backgroundColor='#17171A'

        // subscribe_container_color
        subscribe_container_color.style.backgroundColor='#232531'
        // subscribe_image_color
        _subscribe_image_color[0].setAttribute('class','d-none')
        _subscribe_image_color[1].setAttribute('class','d-block')

        // submenu
        for(i=0;i<submenuCounter.length;i++){
            document.getElementsByClassName('menu_desktop')[0].children[0].children[i].children[1].style.backgroundColor='#17171A'
            document.getElementsByClassName('menu_desktop')[0].children[0].children[i].children[1].style.boxShadow='0px 0px 7px 1px white'
        }

        // backgroundButtonMob
        for(i=0;i<4;i++){
            document.getElementsByClassName('backgroundButtonMob')[i].style.backgroundColor='#232531'
        }

        // backgroundTerms
        for (i=0;i<3;i++){
            document.getElementsByClassName('backgroundTerms')[i].style.backgroundColor='white'
        }

        for(i=0;i<261;i++){
            document.getElementsByClassName('liInside')[i].style.color='white'
        }
        
    }
    else{
        // body color
        _bodyColor.style.backgroundColor='white'
        // headtop main logo
        document.getElementsByTagName('main')[0].style.backgroundColor='white'
        head_top_span[1].style.color='black'
        head_top_span_sun[0].style.display='block'
        head_top_span_sun[1].style.display='none'
        // logo
        _logoDes.style.fill='#17181B'
        _logoMob.style.fill='#17181B'
        _logoFooter.style.fill='#17181B'
        // input form
        document.getElementsByTagName('input')[0].style.backgroundColor='#EFF2F5'
        // menuMobileColor
        menuMobileColor.style.backgroundColor='white'

        // moon sun mob
        moon_sun_mob[0].style.display='block'
        moon_sun_mob[1].style.display='none'

        // price container
        price_container_color.style.backgroundColor='#EFF2F5'

        // _table_container_color
        _table_container_color.style.backgroundColor='white'

        // price Boxes
        for(i=0;i<_priceBoxes.length;i++){
            _priceBoxes[i].style.backgroundColor='white'
        }
        for(i=0;i<slider_box_color.length;i++){
            slider_box_color[i].style.backgroundColor='white'
        }

        // table_watch color
        for(i=0;i<_table_watch_color.length;i++){
            _table_watch_color[i].style.backgroundColor='rgb(166, 176, 194,0.3)'
        }
        // _table_filters_color
        for(i=0;i<_table_filters_color.length;i++){
            _table_filters_color[i].style.backgroundColor='rgb(166, 176, 194,0.3)'
        }
        _list_color.style.backgroundColor='white'
        document.getElementsByClassName('list_color')[0].style.backgroundColor='white'

        // subscribe_container_color
        subscribe_container_color.style.backgroundColor='#EFF2F5'
        // subscribe_image_color
        _subscribe_image_color[0].setAttribute('class','d-block')
        _subscribe_image_color[1].setAttribute('class','d-none')


        // submenu
        for(i=0;i<submenuCounter.length;i++){
            document.getElementsByClassName('menu_desktop')[0].children[0].children[i].children[1].style.backgroundColor='white'
            document.getElementsByClassName('menu_desktop')[0].children[0].children[i].children[1].style.boxShadow='0px 0px 7px 1px rgb(89, 102, 125,0.5)'
        }

        // backgroundButtonMob
        for(i=0;i<4;i++){
            document.getElementsByClassName('backgroundButtonMob')[i].style.backgroundColor='#EFF2F5'
        }

        // backgroundTerms
        for (i=0;i<3;i++){
            document.getElementsByClassName('backgroundTerms')[i].style.backgroundColor='black'
        }

        for(i=0;i<261;i++){
            document.getElementsByClassName('liInside')[i].style.color='black'
        }
    }
    counterDark++

}


// MENU MOBILE
let counterMenuMobile = 1
let menuMobile = document.getElementsByClassName('menu_mobile')[0]
function _menu_mobile_open(){
    menuMobile.style.left='0'
}
function _menu_mobile_close(){
    menuMobile.style.left='-105%'
}


// ACC
let _liACC = document.getElementsByClassName('AccMenu')[0].children
for(i=0; i<_liACC.length; i++){
    _liACC[i].setAttribute('data-status','off')
}
function _ACCmenu(x){
    let _accDisplay = x.children[1]
    let _icon = x.children[0].children[1].children[0]
    if( 
        ((x.getAttribute('data-status')) == 'off') 
    ){
        _accDisplay.style.display='block'
        _icon.style.transform='rotate(-180deg)'
        x.setAttribute('data-status', 'on')
    }
    else{
        _accDisplay.style.display='none'
        _icon.style.transform='rotate(0deg)'
        x.setAttribute('data-status', 'off')
    }  
}

// highlight button
let highligh_button = document.getElementsByClassName('price')[0].children[0].children[1].children[0]
let boxees = document.getElementsByClassName('price')[0].children[2]
highligh_button.setAttribute('data-status','off')
highligh_button.addEventListener('click',function(){
    if(
       (highligh_button.getAttribute('data-status')) == 'off'
    ){
        highligh_button.style.transform='translateX(28px)'
        boxees.style.display='none'
        highligh_button.setAttribute('data-status','on')
    }
    else{
        highligh_button.style.transform='translateX(0px)'
        boxees.style.display='flex'
        highligh_button.setAttribute('data-status','off')
    }

})

// slider
let turn = 0
let rightButton = document.getElementById('right')
let middleButton = document.getElementById('middle')
let leftButton = document.getElementById('left')
let _windowWidth = document.getElementsByClassName('window')[0].clientWidth
let divCounrer = document.querySelectorAll('#bus>div')
document.getElementById('bus').style.width=_windowWidth*(divCounrer.length)+'px'
divCounrer.forEach(para)
function para(item){
    item.style.width=_windowWidth+'px'
}
leftButton.style.backgroundColor='#3861FB'
function _right(){
    rightButton.style.backgroundColor='#3861FB'
    leftButton.style.backgroundColor='#A6B0C2'
    middleButton.style.backgroundColor='#A6B0C2'
    if(turn==0){
        turn=2
        _move() 
        
    }
    if(turn==1){
        turn=2
        _move()
        
    }
}
function _left(){
    leftButton.style.backgroundColor='#3861FB'
    rightButton.style.backgroundColor='#A6B0C2'
    middleButton.style.backgroundColor='#A6B0C2'  
    if(turn==2){
        turn=0
        _move() 

    }
    if(turn==1){
        turn=0
        _move() 
    }  
}
function _middle(){
    leftButton.style.backgroundColor='#A6B0C2'
    rightButton.style.backgroundColor='#A6B0C2'
    middleButton.style.backgroundColor='#3861FB'  
    if(turn==0){
        turn=1
        _move() 
    }
    else if(turn==2){
        turn=1
        _move() 
    }
}
function _move(){
    document.getElementById('bus').style.transform='translateX(-'+(_windowWidth*turn)+'px)' 
}
   